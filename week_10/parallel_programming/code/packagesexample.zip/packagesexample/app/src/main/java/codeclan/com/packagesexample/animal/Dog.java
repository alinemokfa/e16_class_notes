package codeclan.com.packagesexample.animal;

/**
 * Created by user on 25/08/2017.
 */

public class Dog {
    public String name;

    public void bark() {
        System.out.print("Bark!");
    }
}
